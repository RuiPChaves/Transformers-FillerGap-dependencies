To run, use code from Wilcox et al. at https://osf.io/zpfxm/
