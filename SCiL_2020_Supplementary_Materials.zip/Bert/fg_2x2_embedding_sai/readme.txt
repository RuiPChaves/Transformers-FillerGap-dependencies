There are three versions of the experiment:

1. In version 1 the items involve verbs that are optionally intransitive (e.g. "talk (about)")
2. In version 2 the items involve verbs that are not optionally intransitive (e.g. "relied on")
3. In version 3 both versions are compounded.

Results are the same for all versions.